/* Every store function the app calls must actually exist.
 *
 * The screen tests replace store.js with a stub, so a function deleted from the
 * real store still "passes" — which is how db.myGolferId went missing and
 * killed the History screen on its first line. This reads both files as TEXT
 * and compares them, so it cannot be fooled by a stub.
 *
 * Run:  node test/exports.test.mjs
 */
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const app = readFileSync(new URL("../app.js", import.meta.url), "utf8");
const store = readFileSync(new URL("../store.js", import.meta.url), "utf8");

const called = [...new Set(
  [...app.matchAll(/\bdb\.([A-Za-z_$][\w$]*)/g)].map((m) => m[1])
)].sort();

const exported = new Set();
for (const m of store.matchAll(/export\s+(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/g)) exported.add(m[1]);
for (const m of store.matchAll(/export\s+const\s+([A-Za-z_$][\w$]*)/g)) exported.add(m[1]);
for (const m of store.matchAll(/export\s*\{([^}]*)\}/g)) {
  m[1].split(",").forEach((part) => {
    const name = part.split(/\s+as\s+/).pop().trim();
    if (name) exported.add(name);
  });
}

console.log(`\nStore functions the app calls: ${called.length}`);

const missing = called.filter((name) => !exported.has(name));
if (missing.length) {
  console.log("\n  FAIL these are called but not exported from store.js:");
  missing.forEach((name) => console.log(`       db.${name}`));
} else {
  console.log("  ok   every one of them exists in store.js");
}

assert.deepEqual(missing, [], "app.js calls store functions that do not exist");
console.log("\nApp and store agree\n");
