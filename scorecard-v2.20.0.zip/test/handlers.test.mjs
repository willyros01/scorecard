/* Every button must be reachable, and every action must have a handler.
 *
 * Two faults this catches, both of which shipped:
 *   1. a data-* attribute on a button that is missing from the CLICKABLE list
 *      the click listener uses — the Index button did nothing for a release;
 *   2. a data-act="x" with no matching `case "x":` — "Remove the older
 *      sign-ins" and "Invite an admin who doesn't play" were both like this,
 *      because an edit silently failed to apply.
 *
 * Run:  node test/handlers.test.mjs
 */
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const app = readFileSync(new URL("../app.js", import.meta.url), "utf8");

/* ---- 1. clickable attributes vs the listener's selector ---- */

const block = app.slice(app.indexOf("const CLICKABLE = ["), app.indexOf("].map((name)"));
const watched = new Set([...block.matchAll(/"(data-[\w-]+)"/g)].map((m) => m[1]));

/* Attributes that are read, typed into, or handled by their own listener —
   never targets of the main click dispatcher. */
const notClickable = new Set([
  "data-theme", "data-round-detail", "data-share-toggle", "data-close",
  "data-problem", "data-send", "data-quick", "data-invite", "data-newgroup",
  "data-paste", "data-reset-password", "data-armed", "data-kill", "data-name",
  "data-forget-name", "data-tab", "data-tee-field", "data-golfer",
  "data-recalc", "data-reset-invite", "data-pw",
]);

const used = [...new Set(
  [...app.matchAll(/\s(data-[\w-]+)=/g)].map((m) => m[1])
)].filter((name) => !notClickable.has(name));

console.log(`\nClickable attributes in the markup: ${used.length}`);

const unwired = used.filter((name) => !watched.has(name)).sort();
if (unwired.length) {
  console.log("\n  FAIL on buttons but missing from the click selector:");
  unwired.forEach((n) => console.log(`       ${n}  — tapping it will do nothing`));
} else {
  console.log("  ok   every one is wired to the click listener");
}

/* ---- 2. every action has a handler ---- */

const actions = [...new Set([...app.matchAll(/data-act="([a-z-]+)"/g)].map((m) => m[1]))];
const cases = new Set([...app.matchAll(/case "([a-z-]+)":/g)].map((m) => m[1]));

/* new-group has its own dedicated listener rather than a case. */
const noHandler = actions.filter((a) => !cases.has(a) && a !== "new-group").sort();

console.log(`Actions in the markup: ${actions.length}`);
if (noHandler.length) {
  console.log("\n  FAIL these have no handler:");
  noHandler.forEach((a) => console.log(`       data-act="${a}"  — dead button`));
} else {
  console.log("  ok   every action has a handler");
}

assert.deepEqual(unwired, [], "buttons whose taps can never be handled");
assert.deepEqual(noHandler, [], "actions with no handler");
console.log("\nEvery button is reachable\n");
