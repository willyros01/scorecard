#!/bin/sh
# Runs every suite. Use this before packaging — not the individual files.
#   cd /home/claude/v2 && sh test/all.sh
cd "$(dirname "$0")/.." || exit 1
fail=0
for t in loads exports handlers discipline foundation outbox lookup; do
  if node "test/$t.test.mjs" > /tmp/out.$$ 2>&1; then
    printf '  pass  %s\n' "$t"
  else
    printf '  FAIL  %s\n' "$t"
    tail -20 /tmp/out.$$
    fail=1
  fi
done
rm -f /tmp/out.$$
[ $fail -eq 0 ] && echo "\nAll suites pass\n" || echo "\nSOMETHING FAILED — do not package\n"
exit $fail
