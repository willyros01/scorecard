/* loads.test.mjs — does the app actually start?
 *
 * The cheapest test there is, and it has already caught a duplicate declaration
 * that would have stopped the app dead on every device. Everything else in the
 * suite is worthless if the file cannot be imported.
 *
 * Run:  node test/loads.test.mjs
 */
import assert from "node:assert/strict";

/* A browser, in as few lines as will do. */
const g = globalThis;
g.window = g;
g.self = g;

const kept = new Map();
g.localStorage = {
  getItem: (k) => (kept.has(k) ? kept.get(k) : null),
  setItem: (k, v) => kept.set(k, String(v)),
  removeItem: (k) => kept.delete(k),
};

const element = () => ({
  dataset: {}, style: {}, hidden: false, innerHTML: "", textContent: "", value: "",
  classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
  addEventListener() {}, removeEventListener() {}, appendChild() {}, remove() {},
  querySelector: () => null, querySelectorAll: () => [], closest: () => null,
  contains: () => false, setAttribute() {}, getAttribute: () => null, focus() {}, blur() {},
});

g.document = {
  documentElement: element(), body: element(),
  getElementById: () => element(),
  querySelector: () => element(),
  querySelectorAll: () => [],
  createElement: () => element(),
  addEventListener() {},
};
g.location = { hostname: "test", origin: "https://test", pathname: "/", search: "" };
Object.defineProperty(g, "navigator", { value: { onLine: true }, configurable: true });
g.matchMedia = () => ({ matches: false, addEventListener() {} });
g.history = { replaceState() {} };
g.addEventListener = () => {};
g.setInterval = () => 0;
g.URLSearchParams = URLSearchParams;

console.log("\nStarting the app");

let error = null;
try {
  await import("../app.js");
  console.log("  ok   app.js loads");
} catch (e) {
  error = e;
  console.log(`  FAIL app.js will not load\n       ${e.message}`);
}

assert.equal(error, null, "the app does not start");

/* The other modules must load on their own too — app.js importing cleanly does
   not prove store.js would, since a bad ordering can hide behind it. */
for (const name of ["model.js", "store.js", "outbox.js"]) {
  try {
    await import(`../${name}`);
    console.log(`  ok   ${name} loads`);
  } catch (e) {
    console.log(`  FAIL ${name}\n       ${e.message}`);
    error = e;
  }
}

assert.equal(error, null, "a module does not load");
console.log("\nEverything starts\n");
