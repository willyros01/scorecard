/* lookup.test.mjs — reading whatever the course provider sends.
 *
 * We do not control this data and it has changed shape at least three times:
 * a flat array, then { male: [...], female: [...] }, and then those keys not
 * being arrays either — which threw "forEach is not a function" and took the
 * whole search down with a message that hid the reason.
 *
 * So nothing here may assume a shape, and nothing may throw. Anything that
 * cannot be understood is skipped.
 *
 * Run:  node test/lookup.test.mjs
 */
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const src = readFileSync(new URL("../courses-api.js", import.meta.url), "utf8");

/* Pulled from the shipped file so the test cannot drift from the real code. */
const grab = (name) => {
  const start = src.indexOf(`function ${name}(`);
  let depth = 0;
  for (let i = src.indexOf("{", start); i < src.length; i++) {
    if (src[i] === "{") depth++;
    else if (src[i] === "}" && --depth === 0) return src.slice(start, i + 1);
  }
  return "";
};
const teesFrom = new Function(
  "const num=(v)=>{const n=Number(v);return Number.isFinite(n)&&n>0?n:0;};"
  + grab("asList") + grab("teesFrom") + "; return teesFrom;"
)();

let failures = 0;
const test = (name, fn) => {
  try { fn(); console.log(`  ok   ${name}`); }
  catch (e) { console.error(`  FAIL ${name}\n       ${e.message}`); failures++; }
};

console.log("\nEvery shape the provider has sent");

test("a flat array of tees", () => {
  const out = teesFrom([{ tee_name: "Blue", course_rating: 71.2, slope_rating: 131, par_total: 72 }]);
  assert.equal(out.length, 1);
  assert.deepEqual(out[0], { name: "Blue", rating: 71.2, slope: 131, par: 72 });
});

test("male and female lists", () => {
  const out = teesFrom({
    male: [{ tee_name: "Blue", course_rating: 71.2, slope_rating: 131 }],
    female: [{ tee_name: "Red", course_rating: 69, slope_rating: 120 }],
  });
  assert.equal(out.length, 2);
  assert.equal(out[0].name, "Blue (M)");
  assert.equal(out[1].name, "Red (W)");
});

test("male as an OBJECT rather than a list — the shape that broke it", () => {
  const out = teesFrom({ male: { 0: { tee_name: "Blue", course_rating: 71.2, slope_rating: 131 } } });
  assert.equal(out.length, 1);
  assert.equal(out[0].name, "Blue (M)");
});

test("one tee on its own, not in a container", () => {
  const out = teesFrom({ tee_name: "Gold", course_rating: 74, slope_rating: 140 });
  assert.equal(out.length, 1);
  assert.equal(out[0].name, "Gold");
});

test("keys we have never seen are still read", () => {
  const out = teesFrom({
    mens: [{ tee_name: "White", course_rating: 68, slope_rating: 118 }],
    womens: [{ tee_name: "Red", course_rating: 70, slope_rating: 125 }],
  });
  assert.equal(out.length, 2);
  assert.equal(out[0].name, "White (M)");
  assert.equal(out[1].name, "Red (W)");
});

console.log("\nNonsense is skipped, never thrown");

for (const [label, value] of Object.entries({
  "null": null,
  "undefined": undefined,
  "a string": "nonsense",
  "a number": 42,
  "an empty object": {},
  "an empty array": [],
  "a list of nulls": [null, undefined],
  "tees with no rating": [{ tee_name: "Blue" }],
  "tees with a zero slope": [{ tee_name: "Blue", course_rating: 71, slope_rating: 0 }],
})) {
  test(label, () => {
    const out = teesFrom(value);
    assert.ok(Array.isArray(out), "always returns a list");
    assert.equal(out.length, 0, "and nothing unusable gets through");
  });
}

test("the same tee under two keys appears once", () => {
  const tee = { tee_name: "Blue", course_rating: 71.2, slope_rating: 131 };
  const out = teesFrom({ male: [tee], mens: [tee] });
  assert.equal(out.length, 1, "duplicates are dropped");
});

console.log("\nThe two-step lookup");

test("a search result keeps its id even with no tees", () => {
  /* The provider sends only a COUNT of tee boxes in a search result. Courses
     were being DISCARDED for having no tees, which is why a real course came
     back as "no rating and slope are published". */
  const normalize = new Function(
    "const num=(v)=>{const n=Number(v);return Number.isFinite(n)&&n>0?n:0;};"
    + grab("asList") + grab("teesFrom") + grab("normalize") + "; return normalize;"
  )();

  const fromSearch = normalize({
    id: "7k2m9qb4", club_name: "Braeben Golf Course", course_name: "",
    location: { city: "Mississauga", country: "Canada" },
    tees: { male: 4, female: 3 },   /* counts, not tees */
  });
  assert.equal(fromSearch.id, "7k2m9qb4", "the id must survive — it is what the second call needs");
  assert.equal(fromSearch.tees.length, 0, "and counts are correctly read as no tees");
  assert.ok(/Braeben/.test(fromSearch.name));
});

test("the full record yields real tees", () => {
  const normalize = new Function(
    "const num=(v)=>{const n=Number(v);return Number.isFinite(n)&&n>0?n:0;};"
    + grab("asList") + grab("teesFrom") + grab("normalize") + "; return normalize;"
  )();

  /* Shaped exactly like the documented response for GET /v1/courses/{id}. */
  const full = normalize({
    id: "7k2m9qb4", club_name: "Murray Golf Club", course_name: "Course No. 1",
    location: { city: "Murray", state: "KY", country: "United States" },
    tees: {
      female: [{ tee_name: "Blue", course_rating: 75.7, slope_rating: 132, par_total: 73 }],
      male: [{ tee_name: "Blue", course_rating: 71.2, slope_rating: 128, par_total: 72 }],
    },
  });
  assert.equal(full.name, "Murray Golf Club — Course No. 1");
  assert.equal(full.tees.length, 2);
  const blueW = full.tees.find((t) => t.name === "Blue (W)");
  assert.deepEqual(blueW, { name: "Blue (W)", rating: 75.7, slope: 132, par: 73 },
    "par_total is used, not the old guess of 72");
});

console.log("\nThe failure message names its cause");

const explain = new Function(grab("explain") + "; return explain;")();
test("an HTTP status is quoted, not swallowed", () => {
  assert.ok(/404/.test(explain("HTTP_404")));
  assert.ok(/500/.test(explain("HTTP_500")));
  assert.ok(/MYSTERY/.test(explain("MYSTERY")), "even a code we do not know is shown");
});

test("the codes we do know still read plainly", () => {
  assert.ok(/not set up/i.test(explain("NO_KEY")));
  assert.ok(/rejected/i.test(explain("BAD_KEY")));
  assert.ok(/No course matched/i.test(explain("NO_MATCH")));
});

console.log(failures ? `\n${failures} problem(s)\n` : "\nThe lookup holds\n");
process.exitCode = failures ? 1 : 0;
