/* foundation.test.mjs — the handicap maths and the model.
 *
 * These are the numbers people's golf is judged by, so they are checked against
 * the World Handicap System directly, plus every malformed shape that has
 * actually reached them: missing dates, null differentials, empty strings.
 *
 * Run:  node test/foundation.test.mjs
 */
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";
import * as model from "../model.js";

let failures = 0;
const test = (name, fn) => {
  try { fn(); console.log(`  ok   ${name}`); }
  catch (e) { console.error(`  FAIL ${name}\n       ${e.message}`); failures++; }
};
const section = (name) => console.log(`\n${name}`);

section("The World Handicap System sums");

test("a differential is (113 / slope) × (adjusted − rating)", () => {
  /* Willy's 97 at Royal Ontario white tees: 133 slope, 68.8 rating. */
  assert.equal(model.differential(97, 68.8, 133), 24);
  assert.equal(model.differential(90, 68.8, 133), 18);
});

test("a course handicap is index × (slope/113) + (rating − par)", () => {
  /* This is the sum the user asked about: 25.7 at Royal Ontario gives 29,
     which is why a 95 became a net 66. */
  assert.equal(model.courseHandicap(25.7, 133, 68.8, 70), 29);
  assert.equal(model.courseHandicap(24.8, 133, 68.8, 70), 28);
  assert.equal(model.courseHandicap(14.2, 131, 71.2, 72), 16);
});

test("a NEGATIVE course handicap is legitimate, not a fault", () => {
  /* A good player on a course rated below par gets fewer strokes than par.
     Treating this as wrong made tidy.html flag correct rounds for ever. */
  assert.ok(model.courseHandicap(2, 113, 68, 72) < 0);
});

section("The index: best 8 of the last 20");

test("fewer than three rounds means no index at all", () => {
  const two = [
    { roundId: "a", date: "2026-01-01", differential: 20 },
    { roundId: "b", date: "2026-02-01", differential: 18 },
  ];
  assert.equal(model.displayIndex(two), null);
});

test("the index is never negative and never above 54", () => {
  const brilliant = Array.from({ length: 20 }, (_, i) => ({
    roundId: `r${i}`, date: `2026-01-${String(i + 1).padStart(2, "0")}`, differential: -30,
  }));
  const index = model.displayIndex(brilliant);
  assert.ok(index === null || index >= 0, `got ${index}`);

  const dreadful = Array.from({ length: 20 }, (_, i) => ({
    roundId: `r${i}`, date: `2026-01-${String(i + 1).padStart(2, "0")}`, differential: 90,
  }));
  const high = model.displayIndex(dreadful);
  assert.ok(high === null || high <= 54, `got ${high}`);
});

test("the sliding scale decides how many rounds count", () => {
  assert.equal(model.countingRounds(3), 1);
  assert.equal(model.countingRounds(6), 2);
  assert.equal(model.countingRounds(9), 3);
  assert.equal(model.countingRounds(18), 6);
  assert.equal(model.countingRounds(20), 8);
  assert.equal(model.countingRounds(45), 8, "never more than eight");
  assert.equal(model.countingRounds(2), 0, "and none below three rounds");
});

section("Malformed data that has actually reached the model");

test("null is rejected as a differential — Number(null) is 0", () => {
  const window = [
    { roundId: "a", date: "2026-01-01", differential: 20 },
    { roundId: "b", date: "2026-02-01", differential: 18 },
    { roundId: "c", date: "2026-03-01", differential: 22 },
    { roundId: "d", date: "2026-04-01", differential: null },
    { roundId: "e", date: "2026-05-01" },
  ];
  const clean = model.sanitizeWindow(window, ["a", "b", "c", "d", "e"]);
  assert.equal(clean.length, 3, "the two unusable entries are dropped, not read as zero");
});

test("a round with no date does not break the period filter", () => {
  assert.doesNotThrow(() => model.inPeriod({ id: "r1", gross: 90 }, { year: "2026", month: "08" }));
  assert.equal(model.inPeriod({ id: "r1", gross: 90 }, { year: "2026", month: "08" }), false);
  assert.equal(model.inPeriod({ id: "r1", gross: 90 }, { year: "", month: "" }), true);
});

test("dated rounds still filter exactly as before", () => {
  const round = { id: "r2", date: "2026-08-14", gross: 90 };
  assert.equal(model.inPeriod(round, { year: "2026", month: "08" }), true);
  assert.equal(model.inPeriod(round, { year: "2026", month: "07" }), false);
  assert.equal(model.inPeriod(round, { year: "", month: "" }), true);
});

section("A starting handicap for somebody with no rounds yet");

test("it is used only until real rounds exist", () => {
  const seeded = { name: "Sam", manualIndex: 14.2, recentWindow: [] };
  assert.deepEqual(model.effectiveIndex(seeded), { index: 14.2, source: "manual" });

  const played = { name: "Sam", manualIndex: 14.2, recentWindow: [
    { roundId: "a", date: "2026-01-01", differential: 20 },
    { roundId: "b", date: "2026-02-01", differential: 18 },
    { roundId: "c", date: "2026-03-01", differential: 22 },
  ] };
  assert.equal(model.effectiveIndex(played).source, "rounds",
    "a calculated index must always beat a remembered one");
});

test("a typed index is kept inside the allowed range", () => {
  assert.equal(model.clampIndex(-5), 0);
  assert.equal(model.clampIndex(99), 54);
  assert.equal(model.clampIndex("12.34"), 12.3);
  assert.equal(model.clampIndex(""), null, "empty must not become scratch");
  assert.equal(model.clampIndex("nonsense"), null);
});

section("Games, including tournaments");

test("an ordinary game has no end date and covers one day", () => {
  const g = model.buildGame({ assocId: "a", date: "2026-09-12", courseId: "c", createdBy: "u" });
  assert.equal(g.endDate, null);
  assert.equal(model.gameCovers(g, "2026-09-12"), true);
  assert.equal(model.gameCovers(g, "2026-09-13"), false);
  assert.equal(model.gameDays(g), 1);
});

test("a tournament covers every day in its range, inclusive", () => {
  const g = model.buildGame({ assocId: "a", date: "2026-09-12", endDate: "2026-09-14",
    courseId: "c", createdBy: "u" });
  assert.equal(model.gameCovers(g, "2026-09-11"), false);
  assert.equal(model.gameCovers(g, "2026-09-13"), true);
  assert.equal(model.gameCovers(g, "2026-09-14"), true);
  assert.equal(model.gameCovers(g, "2026-09-15"), false);
  assert.equal(model.gameDays(g), 2 + 1);
  assert.equal(model.gameCovers(g, undefined), false, "a round with no date is never swept in");
});

test("an end date before the start is ignored", () => {
  const g = model.buildGame({ assocId: "a", date: "2026-09-12", endDate: "2026-09-01",
    courseId: "c", createdBy: "u" });
  assert.equal(g.endDate, null);
});

test("net and gross rank independently in a standing", () => {
  /* The higher handicapper can lead on net while losing on gross — the whole
     point of a handicap, and the share must show each in its own order. */
  const game = model.buildGame({ assocId: "a", date: "2026-09-12", endDate: "2026-09-13",
    courseId: "c", createdBy: "u" });
  const golfers = [
    { id: "a", name: "Willy", handicapIndex: 25.7 },
    { id: "b", name: "Rey", handicapIndex: 17.0 },
  ];
  const rounds = [
    { id: "r1", golferId: "a", date: "2026-09-12", gross: 97, adjusted: 97, courseHandicap: 29 },
    { id: "r2", golferId: "a", date: "2026-09-13", gross: 94, adjusted: 94, courseHandicap: 29 },
    { id: "r3", golferId: "b", date: "2026-09-12", gross: 91, adjusted: 91, courseHandicap: 19 },
    { id: "r4", golferId: "b", date: "2026-09-13", gross: 93, adjusted: 93, courseHandicap: 19 },
  ];
  const standing = model.gameStandings(rounds, golfers, game);
  assert.equal(standing.players[0].name, "Willy", "leads on net");
  assert.equal(standing.players[0].totalNet, 133);

  const byGross = [...standing.players].sort((x, y) => x.totalGross - y.totalGross);
  assert.equal(byGross[0].name, "Rey", "but Rey leads on gross");
  assert.equal(byGross[0].totalGross, 184);
});

test("a leaderboard works out a net score when none was frozen", () => {
  const golfers = [{ id: "g1", name: "Sam", manualIndex: 14.2, recentWindow: [] }];
  const rounds = [{ id: "r1", golferId: "g1", gross: 95, adjusted: 95,
    courseHandicap: null, slope: 131, rating: 71.2, par: 72 }];
  const [row] = model.gameLeaderboard(rounds, golfers);
  assert.ok(row.net != null, "a known handicap must not leave a blank net score");
  assert.equal(row.estimated, true, "and it is marked worked-out, not frozen");
});

section("Our own date grid");

const appSource = readFileSync(new URL("../app.js", import.meta.url), "utf8");
const grabFn = (name) => {
  const start = appSource.indexOf(`function ${name}(`);
  let depth = 0;
  for (let i = appSource.indexOf("{", start); i < appSource.length; i++) {
    if (appSource[i] === "{") depth++;
    else if (appSource[i] === "}" && --depth === 0) return appSource.slice(start, i + 1);
  }
  return "";
};
const cal = new Function(`${grabFn("shiftMonth")}${grabFn("dayGrid")}; return { shiftMonth, dayGrid };`)();

test("moving a month crosses the year correctly", () => {
  assert.equal(cal.shiftMonth("2026-12", 1), "2027-01");
  assert.equal(cal.shiftMonth("2026-01", -1), "2025-12");
});

test("February knows about leap years", () => {
  assert.equal(cal.dayGrid("2028-02").filter(Boolean).length, 29);
  assert.equal(cal.dayGrid("2026-02").filter(Boolean).length, 28);
});

test("the grid starts on the right weekday", () => {
  /* 1 August 2026 is a Saturday, so Monday-first leaves five blanks. */
  assert.equal(cal.dayGrid("2026-08").findIndex(Boolean), 5);
  assert.equal(cal.dayGrid("2026-06").findIndex(Boolean), 0, "1 June 2026 is a Monday");
});

console.log(failures ? `\n${failures} problem(s)\n` : "\nThe maths holds\n");
process.exitCode = failures ? 1 : 0;
