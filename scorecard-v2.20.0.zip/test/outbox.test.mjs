/* outbox.test.mjs — the offline write queue.
 *
 * This is the part most likely to lose somebody's round, so it is tested
 * against the failures that actually happen on a golf course: no signal
 * mid-round, a write rejected once and accepted on retry, and a write that can
 * never succeed sitting at the front of the queue.
 *
 * Run:  node test/outbox.test.mjs
 */
import assert from "node:assert/strict";

const store = new Map();
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
  clear: () => store.clear(),
};

const outbox = await import("../outbox.js");

let failures = 0;
const test = async (name, fn) => {
  store.clear();
  try { await fn(); console.log(`  ok   ${name}`); }
  catch (e) { console.error(`  FAIL ${name}\n       ${e.message}`); failures++; }
};
const section = (name) => console.log(`\n${name}`);

section("Keeping a round when there is no signal");

await test("a queued write survives and replays", async () => {
  outbox.enqueue({ type: "set", path: ["a", "g1", "rounds", "r1"], data: { gross: 90 } });
  assert.equal(outbox.count(), 1);

  const sent = [];
  const result = await outbox.flush(async (op) => { sent.push(op.path[3]); });
  assert.deepEqual(sent, ["r1"]);
  assert.equal(outbox.count(), 0, "the queue drains once it goes through");
  assert.equal(result.sent, 1);
});

await test("a write refused once is retried, not lost", async () => {
  outbox.enqueue({ type: "set", path: ["a", "g1", "rounds", "r2"], data: { gross: 91 } });

  let attempts = 0;
  await outbox.flush(async () => { attempts++; throw new Error("network down"); });
  assert.equal(attempts, 1);
  assert.equal(outbox.count(), 1, "still queued after a temporary failure");

  await outbox.flush(async () => {});
  assert.equal(outbox.count(), 0, "and it goes through on the next attempt");
});

section("A write that can never succeed must not block the rest");

await test("a refused write is abandoned at once, not retried fifty times", async () => {
  outbox.enqueue({ type: "set", path: ["a", "g1", "rounds", "r1"], data: {} });
  outbox.enqueue({ type: "set", path: ["a", "g1", "rounds", "r2"], data: {} });

  const done = [];
  const result = await outbox.flush(async (op) => {
    if (op.path[3] === "r1") {
      const e = new Error("Missing or insufficient permissions.");
      e.code = "permission-denied";
      throw e;
    }
    done.push(op.path[3]);
  });

  assert.deepEqual(done, ["r2"], "the second write still went, despite the first being refused");
  assert.equal(result.failed, 1);
  assert.equal(outbox.count(), 0, "nothing is left spinning in the queue");
  const gaveUp = outbox.abandoned().filter((o) => o.path && o.path[3] === "r1");
  assert.equal(gaveUp.length, 1);
  assert.equal(gaveUp[0].permanent, true, "and it knew the refusal was final");
});

await test("a round posted then deleted while offline cancels itself", async () => {
  const path = ["a", "g1", "rounds", "r9"];
  outbox.enqueueOrMerge({ type: "set", path, data: { gross: 90 } });
  assert.equal(outbox.count(), 1);

  outbox.enqueueOrMerge({ type: "delete", path });
  assert.equal(outbox.count(), 0,
    "both sides cancel — nothing needs to reach the database at all");
});

await test("a delete for a round that DID upload still goes", async () => {
  outbox.enqueueOrMerge({ type: "delete", path: ["a", "g1", "rounds", "r8"] });
  assert.equal(outbox.count(), 1, "with no queued create to cancel against, the delete stands");
});

section("Batches are all or nothing");

await test("a batch is queued as ONE item, not one per document", async () => {
  outbox.enqueue({
    type: "batch",
    writes: [
      { op: "set", path: ["a", "g1", "rounds", "r1"], data: {} },
      { op: "set", path: ["golfers", "p1"], data: {} },
    ],
  });
  assert.equal(outbox.count(), 1, "the guarantee is the batch, so it queues whole");
});

await test("a failed batch is retried whole — never half applied", async () => {
  outbox.enqueue({
    type: "batch",
    writes: [
      { op: "set", path: ["a", "g1", "rounds", "r1"], data: {} },
      { op: "set", path: ["golfers", "p1"], data: {} },
    ],
  });

  await outbox.flush(async () => { throw new Error("network down"); });
  assert.equal(outbox.count(), 1, "the whole batch waits, not the surviving half");

  let seen = null;
  await outbox.flush(async (op) => { seen = op; });
  assert.equal(seen.type, "batch");
  assert.equal(seen.writes.length, 2, "and it replays with both writes intact");
});

console.log(failures ? `\n${failures} problem(s)\n` : "\nThe queue holds\n");
process.exitCode = failures ? 1 : 0;
