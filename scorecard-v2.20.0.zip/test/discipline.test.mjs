/* discipline.test.mjs — habits that have each cost a release.
 *
 * These are not clever tests. Each one exists because the fault below actually
 * shipped and the user found it:
 *   · a message set but never drawn — a button that looks dead;
 *   · database work with no waiting card — looks dead, and can be tapped twice,
 *     which once created four copies of the same golfer;
 *   · a batch containing a membership AND a write whose RULE needs that
 *     membership — Firestore refuses the lot;
 *   · success delivered through the ERROR dialog, which mails it as a BUG.
 *
 * Run:  node test/discipline.test.mjs
 */
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const app = readFileSync(new URL("../app.js", import.meta.url), "utf8");
const store = readFileSync(new URL("../store.js", import.meta.url), "utf8");
const rules = readFileSync(new URL("../firestore.rules", import.meta.url), "utf8");

let failures = 0;
const report = (label, bad, why) => {
  if (bad.length) {
    console.log(`\n  FAIL ${label}`);
    bad.forEach((b) => console.log(`       ${b}  — ${why}`));
    failures++;
  } else {
    console.log(`  ok   ${label}`);
  }
};

/* Handler bodies: switch cases and named async functions. */
const bodies = [];
for (const chunk of app.split(/\n    case "/).slice(1)) {
  const name = chunk.slice(0, chunk.indexOf('"'));
  const end = chunk.indexOf("\n    case ");
  bodies.push([`case "${name}"`, end === -1 ? chunk : chunk.slice(0, end)]);
}
for (const [, name, body] of app.matchAll(/\nasync function (\w+)\(([\s\S]*?)\n\}/g)) {
  bodies.push([`function ${name}()`, body]);
}

console.log("\nHabits that have each cost a release");

/* 1. a message nobody would see */
const silent = bodies
  .filter(([, b]) => /flashMsg\(/.test(b))
  .filter(([, b]) => !/render\(\)|openProblem\(|openNotice\(|openShare\(|location\.reload\(\)/.test(b))
  .map(([where]) => where);
report("every message reaches the screen", silent, "sets a message but never redraws");

/* 2. database work with no waiting card */
const exempt = new Set(["start", "settleGroupInner", "settleGroup", "render", "boot"]);
const noCard = bodies
  .filter(([where, b]) => /await db\./.test(b) && !exempt.has(where.replace(/^function |\(\)$/g, "")))
  .filter(([, b]) => !/busy\(/.test(b))
  .map(([where]) => where);
report("every database call raises the waiting card", noCard, "will look dead, and can be tapped twice");

/* 3. a card raised and never lowered */
const stuck = [];
for (const [, name, body] of app.matchAll(/\nasync function (\w+)\(([\s\S]*?)\n\}/g)) {
  if (/busy\(/.test(body) && !/idle\(\)|idleAll\(\)/.test(body)) stuck.push(`function ${name}()`);
}
report("every waiting card is lowered again", stuck, "leaves the screen frozen behind it");

/* 4. the batch-ordering trap */
const dependent = new Set();
for (const [, name, body] of rules.matchAll(/match \/(\w+)\/\{[^}]+\}\s*\{([\s\S]*?)\n      \}/g)) {
  if (/isMember\(|isAdmin\(|isOwner\(/.test(body)) dependent.add(name);
}
const badBatches = [];
for (const match of store.matchAll(/commitTogether\(\[([\s\S]*?)\], "([^"]+)"\)/g)) {
  const [, blockText, label] = match;
  const paths = [...blockText.matchAll(/path: \[([^\]]+)\]/g)].map((m) => m[1]);
  if (!paths.some((p) => /"members"/.test(p))) continue;
  const alsoDependent = paths.filter((p) =>
    [...dependent].some((n) => new RegExp(`"${n}"`).test(p)) && !/"members"/.test(p));
  if (alsoDependent.length) badBatches.push(`"${label}"`);
}
report("no batch depends on a membership it is creating", badBatches,
  "Firestore evaluates every write against the state BEFORE the batch");

/* 5. success through the error dialog */
const soundsPositive = (t) => {
  const s = t.toLowerCase();
  if (/\b(could not|couldn't|cannot|failed|did not|didn't|wrong|problem|error|refused|denied|too )/.test(s)) return false;
  return /\b(you're in|welcome|added|saved|done|ready|success|created|restored|updated|already)\b/.test(s);
};
const misused = [...app.matchAll(/openProblem\(\{\s*\n?\s*title: "([^"]+)"/g)]
  .map((m) => m[1]).filter(soundsPositive).map((t) => `"${t}"`);
report("the error dialog is used only for errors", misused,
  "goes to the maintainer's inbox labelled BUG");

/* 6. golfer writes must name their group */
const unnamed = [];
for (const m of store.matchAll(/path: \["golfers", [^\]]*\], data: (\{[^}]*\})/g)) {
  if (!/editedIn/.test(m[1]) && !/linkedUid: uid/.test(m[1])) unnamed.push(m[1].slice(0, 60));
}
report("golfer writes name the group they act for", unnamed,
  "the rules refuse a write to somebody else's golfer without editedIn");

/* 7. no duplicate top-level declarations — one of these stopped the app dead */
const seen = {};
for (const m of app.matchAll(/^(?:const|let|function|async function) (\w+)/gm)) {
  seen[m[1]] = (seen[m[1]] || 0) + 1;
}
const dupes = Object.entries(seen).filter(([, n]) => n > 1).map(([n]) => n);
report("no duplicate top-level declarations", dupes, "the app will not load at all");

assert.equal(failures, 0, "discipline checks failed");
console.log("\nThe habits hold\n");
